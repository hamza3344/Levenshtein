﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace levenshtein
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string word1 = textBox1.Text;
            string word2 = textBox2.Text;
            //create matrix
            double[,] matrix = new double[word2.Length + 1, word1.Length + 1];
            //initalization of row with 0,1 so on
            for(int i=0;i<matrix.GetLength(0);i=i+1)
            {
                matrix[i, 0] = i;
            }

            //initalization of column with 0,1 so on
            for (int i = 0; i < matrix.GetLength(1); i = i + 1)
            {
                matrix[0, i] = i;
            }
            //iteration
            for(int row=1;row<matrix.GetLength(0);row=row+1)
            {
                for (int col = 1; col < matrix.GetLength(1); col = col + 1)
                {
                    //charaters are same
                    if(word1[col-1]==word2[row-1])
                    {
                        matrix[row, col] = matrix[row - 1, col - 1];
                    }



                    //charaters are different
                    else
                    {
                        matrix[row, col] = Math.Min(matrix[row, col - 1], Math.Min(
                            matrix[row - 1, col], matrix[row - 1, col - 1])) + 1;
                    }
                }
            }
            MessageBox.Show(matrix[matrix.GetLength(0) - 1, matrix.GetLength(1) - 1].ToString());
            








            //last value in matrix represent number of operation to change string to other
        }
    }
}
